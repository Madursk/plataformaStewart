/*
 * File:   Main.c
 * Author: MiguelAng
 *
 * Created on 10 de marzo de 2018, 03:42 PM
 */


#include <xc.h>
#include "pic18f4431.h"
#include "ConfigurationBits.h"
#include "Datatypes.h"




void PWM_write(uint8_t dutyCycle);
void QEI_init(void);
void I2C_init(void);
void GPIO_init(void);
void PERIPH_init(uint8_t dutyCycle);
void Interrupt_enable(void);

struct
{
    uint8_t i2cMode :1;  //I2C master or slave flag
    uint8_t         :7; //padding
}GPREG;

void interrupt ISR_high(void)
{
    if(SSPIE == 1 && SSPIF == 1)
    {
        if(GPREG.i2cMode == 1)
        {
            SSPIF = 0;
        }//end I2C master mode
        else
        {
            SSPIF = 0;
        }//end I2C slave mode
    }//end I2C communication  
    
}//end interrupts handler

void main(void)
{
    GPIO_init();
    PERIPH_init(80);
    Interrupt_enable();
    //PWM_write(50);
    while(1)
    {
      
    }
    
}//end main

void I2C_init()
{
    SSPCON =0b00100110; //I2C configuration bit-7 No collision,bit-6 No overflow
}//end I2C              //bit-5 enable SP set SDA and SCL, bit 3-0 0110 I2C slave 7-bit addrs

void GPIO_init()
{
    LATC2 = 0;  //Output register
    RC2 = 0;    // Input register
    TRISC2 = 0; 
    TRISB2 = 0; // PWM/CCP1 pin
    TRISD3 = 1; //SCL pin
    TRISD2 = 1; //SDA pin
}//end gpio_init

void PERIPH_init(uint8_t dutyCycle)
{
    CCP1CON = 0b00001100; //PWM: duty cycle in 8 bits
    T2CON = 0b00000110; //PWM: postscaler = 1 prescaler  = 16
    PR2 = 125;  //period of 1 ms counts every 8 us
    CCPR1L = dutyCycle*125/100;
    
}//end peripherals initialization function


void PWM_write(uint8_t dutyCycle)
{
    //
}//end PWM write dutyCycle function


void Interrupt_enable()
{
   SSPIE = 1; //Synchronoues serial port interrupt enable
   SSPEN = 1; //Synchronous serial port priority enable
   IPEN=1;    //Interrupt priority enable
   GIE = 1;   //Global interrupt enable
}//end enable interrupts function